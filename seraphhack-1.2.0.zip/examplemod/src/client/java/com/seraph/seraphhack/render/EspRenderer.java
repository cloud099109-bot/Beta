package com.seraph.seraphhack.render;

import com.seraph.seraphhack.Handler;
import com.seraph.seraphhack.SeraphHackClient;
import com.seraph.seraphhack.scanner.ChunkResult;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.ChestBlockEntity;
import net.minecraft.block.entity.ShulkerBoxBlockEntity;
import net.minecraft.block.entity.BarrelBlockEntity;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.DyeColor;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.chunk.WorldChunk;
import org.joml.Matrix4f;

public final class EspRenderer {
    private EspRenderer() {}

    public static void render(WorldRenderContext ctx) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.world == null || client.player == null || ctx.matrixStack() == null) return;
        VertexConsumer vc = ctx.consumers().getBuffer(RenderLayer.getLines());
        Matrix4f matrix = ctx.matrixStack().peek().getPositionMatrix();
        Vec3d cam = ctx.camera().getPos();
        double range2 = Handler.espRange * (double)Handler.espRange;

        if (Handler.playerEsp) {
            for (PlayerEntity p : client.world.getPlayers()) {
                if (p == client.player || p.isSpectator() || p.squaredDistanceTo(client.player) > range2) continue;
                drawBox(matrix, vc, p.getBoundingBox().offset(-cam.x, -cam.y, -cam.z), 255, 70, 70);
            }
        }

        int cr = Math.max(1, (Handler.espRange / 16) + 1);
        int pcx = client.player.getChunkPos().x, pcz = client.player.getChunkPos().z;
        for (int dx = -cr; dx <= cr; dx++) for (int dz = -cr; dz <= cr; dz++) {
            WorldChunk chunk = client.world.getChunkManager().getWorldChunk(pcx + dx, pcz + dz, false);
            if (chunk == null) continue;
            for (BlockEntity be : chunk.getBlockEntities().values()) {
                if (be == null) continue;
                BlockPos p = be.getPos();
                if (p.getSquaredDistance(client.player.getPos()) > range2) continue;
                int[] color = colorFor(be);
                if (color == null) continue;
                drawBox(matrix, vc, new Box(p).offset(-cam.x, -cam.y, -cam.z), color[0], color[1], color[2]);
            }
        }

        if (Handler.chunkBoxes && SeraphHackClient.SCANNER != null) {
            for (ChunkResult r : SeraphHackClient.SCANNER.getResults()) {
                if (!r.suspicious) continue;
                Box b = new Box(r.chunkX * 16, Handler.minY, r.chunkZ * 16,
                        r.chunkX * 16 + 16, Handler.maxY + 1, r.chunkZ * 16 + 16)
                        .offset(-cam.x, -cam.y, -cam.z);
                drawBox(matrix, vc, b, 255, 40, 40);
            }
        }
    }

    private static int[] colorFor(BlockEntity be) {
        if (be instanceof ChestBlockEntity) {
            if (Handler.chestEsp && be.getCachedState().isOf(Blocks.CHEST)) return new int[]{255, 170, 40};
            if (Handler.trappedChestEsp && be.getCachedState().isOf(Blocks.TRAPPED_CHEST)) return new int[]{255, 60, 60};
        }
        if (be instanceof BarrelBlockEntity && Handler.barrelEsp) return new int[]{170, 110, 50};
        if (be instanceof ShulkerBoxBlockEntity sb && Handler.shulkerEsp) {
            DyeColor c = sb.getColor();
            if (c == null) return new int[]{170, 80, 220};
            int rgb = c.getSignColor();
            return new int[]{(rgb >> 16) & 255, (rgb >> 8) & 255, rgb & 255};
        }
        return null;
    }

    private static void drawBox(Matrix4f m, VertexConsumer v, Box b, int r, int g, int bl) {
        line(m,v,b.minX,b.minY,b.minZ,b.maxX,b.minY,b.minZ,r,g,bl);
        line(m,v,b.maxX,b.minY,b.minZ,b.maxX,b.minY,b.maxZ,r,g,bl);
        line(m,v,b.maxX,b.minY,b.maxZ,b.minX,b.minY,b.maxZ,r,g,bl);
        line(m,v,b.minX,b.minY,b.maxZ,b.minX,b.minY,b.minZ,r,g,bl);
        line(m,v,b.minX,b.maxY,b.minZ,b.maxX,b.maxY,b.minZ,r,g,bl);
        line(m,v,b.maxX,b.maxY,b.minZ,b.maxX,b.maxY,b.maxZ,r,g,bl);
        line(m,v,b.maxX,b.maxY,b.maxZ,b.minX,b.maxY,b.maxZ,r,g,bl);
        line(m,v,b.minX,b.maxY,b.maxZ,b.minX,b.maxY,b.minZ,r,g,bl);
        line(m,v,b.minX,b.minY,b.minZ,b.minX,b.maxY,b.minZ,r,g,bl);
        line(m,v,b.maxX,b.minY,b.minZ,b.maxX,b.maxY,b.minZ,r,g,bl);
        line(m,v,b.maxX,b.minY,b.maxZ,b.maxX,b.maxY,b.maxZ,r,g,bl);
        line(m,v,b.minX,b.minY,b.maxZ,b.minX,b.maxY,b.maxZ,r,g,bl);
    }

    private static void line(Matrix4f m, VertexConsumer v, double x1,double y1,double z1,double x2,double y2,double z2,int r,int g,int b) {
        v.vertex(m,(float)x1,(float)y1,(float)z1).color(r,g,b,255).normal(0,1,0);
        v.vertex(m,(float)x2,(float)y2,(float)z2).color(r,g,b,255).normal(0,1,0);
    }
}
