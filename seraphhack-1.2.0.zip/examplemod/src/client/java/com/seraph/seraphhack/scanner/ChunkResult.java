package com.seraph.seraphhack.scanner;

public final class ChunkResult {
    public final int chunkX, chunkZ;
    public int flatBlocks, artificialBlocks, airBlocks, tunnelBlocks;
    public double score;
    public boolean suspicious;

    public ChunkResult(int chunkX, int chunkZ) { this.chunkX = chunkX; this.chunkZ = chunkZ; }

    public void calculate() {
        score = Math.min(100.0,
                Math.min(35, flatBlocks * .12) +
                Math.min(30, artificialBlocks * .35) +
                Math.min(20, airBlocks * .08) +
                Math.min(20, tunnelBlocks * .25));
        suspicious = score >= 60.0;
    }
}
