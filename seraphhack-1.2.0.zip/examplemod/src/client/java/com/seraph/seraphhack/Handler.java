package com.seraph.seraphhack;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.math.MathHelper;

public final class Handler {
    private Handler() {}

    public static boolean flycam = false;
    public static boolean flyElytra = false;
    public static boolean autoTotem = false;

    public static boolean playerEsp = true;
    public static boolean chestEsp = true;
    public static boolean trappedChestEsp = true;
    public static boolean barrelEsp = true;
    public static boolean shulkerEsp = true;
    public static boolean scanner = true;
    public static boolean chunkBoxes = true;
    public static boolean underground = true;
    public static boolean flatDetection = true;
    public static boolean tunnelDetection = true;
    public static boolean airPocketDetection = true;

    public static float flySpeed = 0.50f;
    public static int espRange = 128;
    public static int scanRadius = 4;
    public static int minY = -64;
    public static int maxY = 25;
    public static int scanInterval = 40;

    private static int ticks;
    private static int totemCooldown;
    private static int elytraCooldown;

    public static void tick(MinecraftClient client) {
        if (client.player == null || client.world == null) return;
        if (totemCooldown > 0) totemCooldown--;
        if (elytraCooldown > 0) elytraCooldown--;

        if (flycam) handleFly(client.player);
        if (flyElytra) handleElytra(client.player);
        if (autoTotem) handleAutoTotem(client);

        if (scanner && ++ticks >= scanInterval) {
            ticks = 0;
            if (SeraphHackClient.SCANNER != null) {
                SeraphHackClient.SCANNER.scanAround(client, client.player.getChunkPos().x, client.player.getChunkPos().z);
            }
        }
    }

    private static void handleFly(ClientPlayerEntity player) {
        if (!player.getAbilities().allowFlying) return;
        player.getAbilities().flying = true;
        player.getAbilities().setFlySpeed(MathHelper.clamp(flySpeed / 10f, 0.01f, 1f));
    }

    private static void handleElytra(ClientPlayerEntity player) {
        ItemStack chest = player.getEquippedStack(EquipmentSlot.CHEST);
        if (!chest.isOf(Items.ELYTRA) || player.isFallFlying() || elytraCooldown != 0) return;
        if (!player.isOnGround() && player.fallDistance > 1f && player.getVelocity().y < 0) {
            player.startFallFlying();
            elytraCooldown = 5;
        }
    }

    private static void handleAutoTotem(MinecraftClient client) {
        ClientPlayerEntity p = client.player;
        if (totemCooldown != 0 || !p.getOffHandStack().isEmpty() || client.interactionManager == null) return;
        int inv = -1;
        for (int i = 0; i < p.getInventory().size(); i++) {
            if (p.getInventory().getStack(i).isOf(Items.TOTEM_OF_UNDYING)) { inv = i; break; }
        }
        if (inv < 0) return;
        int slot = inv < 9 ? 36 + inv : inv;
        client.interactionManager.clickSlot(p.playerScreenHandler.syncId, slot, 40, SlotActionType.SWAP, p);
        totemCooldown = 8;
    }

    public static void disableAll(MinecraftClient client) {
        flycam = flyElytra = autoTotem = false;
        playerEsp = chestEsp = trappedChestEsp = barrelEsp = shulkerEsp = false;
        scanner = chunkBoxes = underground = flatDetection = tunnelDetection = airPocketDetection = false;
        resetFlight(client);
    }

    public static void resetFlight(MinecraftClient client) {
        if (client.player == null) return;
        if (client.player.getAbilities().allowFlying) client.player.getAbilities().flying = false;
        client.player.getAbilities().setFlySpeed(0.05f);
    }
}
