package com.seraph.seraphhack.gui;

import com.seraph.seraphhack.Handler;
import com.seraph.seraphhack.SeraphHackClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

public final class SeraphScreen extends Screen {
    private static final int W = 320, H = 360;
    private int left, top;
    public SeraphScreen() { super(Text.literal("Seraph Hack")); }

    @Override protected void init() {
        left=(width-W)/2; top=(height-H)/2; int x=left+20,w=W-40;
        add(x,top+34,w,"Fly Camera",() -> Handler.flycam=!Handler.flycam);
        add(x,top+59,w,"Player ESP",() -> Handler.playerEsp=!Handler.playerEsp);
        add(x,top+84,w,"Chest ESP",() -> Handler.chestEsp=!Handler.chestEsp);
        add(x,top+109,w,"Trapped Chest",() -> Handler.trappedChestEsp=!Handler.trappedChestEsp);
        add(x,top+134,w,"Barrel ESP",() -> Handler.barrelEsp=!Handler.barrelEsp);
        add(x,top+159,w,"Shulker ESP (all colors)",() -> Handler.shulkerEsp=!Handler.shulkerEsp);
        add(x,top+184,w,"Chunk Boxes",() -> Handler.chunkBoxes=!Handler.chunkBoxes);
        add(x,top+209,w,"Base Scanner",() -> Handler.scanner=!Handler.scanner);
        add(x,top+234,w,"Underground Scan",() -> Handler.underground=!Handler.underground);
        add(x,top+259,w,"Flat Detection",() -> Handler.flatDetection=!Handler.flatDetection);
        add(x,top+284,w,"Tunnel Detection",() -> Handler.tunnelDetection=!Handler.tunnelDetection);
        add(x,top+309,w,"Clear Scanner",() -> { if (SeraphHackClient.SCANNER!=null) SeraphHackClient.SCANNER.clear(); });
    }

    private void add(int x,int y,int w,String label,Runnable action) {
        addDrawableChild(ButtonWidget.builder(Text.literal(label+": "+state(label)), b -> { action.run(); b.setMessage(Text.literal(label+": "+state(label))); })
                .dimensions(x,y,w,20).build());
    }

    private String state(String label) {
        return switch(label) {
            case "Fly Camera" -> Handler.flycam?"ON":"OFF";
            case "Player ESP" -> Handler.playerEsp?"ON":"OFF";
            case "Chest ESP" -> Handler.chestEsp?"ON":"OFF";
            case "Trapped Chest" -> Handler.trappedChestEsp?"ON":"OFF";
            case "Barrel ESP" -> Handler.barrelEsp?"ON":"OFF";
            case "Shulker ESP (all colors)" -> Handler.shulkerEsp?"ON":"OFF";
            case "Chunk Boxes" -> Handler.chunkBoxes?"ON":"OFF";
            case "Base Scanner" -> Handler.scanner?"ON":"OFF";
            case "Underground Scan" -> Handler.underground?"ON":"OFF";
            case "Flat Detection" -> Handler.flatDetection?"ON":"OFF";
            case "Tunnel Detection" -> Handler.tunnelDetection?"ON":"OFF";
            default -> "OK";
        };
    }

    @Override public void render(DrawContext c,int mx,int my,float d) {
        renderBackground(c,mx,my,d);
        c.fill(left,top,left+W,top+H,0xEE101014);
        c.fill(left,top,left+W,top+28,0xFF24242C);
        c.drawTextWithShadow(textRenderer,"SERAPH HACK",left+12,top+9,0xFFFFFF);
        super.render(c,mx,my,d);
    }
    @Override public boolean shouldPause(){return false;}
}
