package com.seraph.seraphhack;

import com.seraph.seraphhack.gui.SeraphScreen;
import com.seraph.seraphhack.render.EspRenderer;
import com.seraph.seraphhack.scanner.ChunkScanner;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public final class SeraphHackClient implements ClientModInitializer {
    public static KeyBinding OPEN_GUI;
    public static KeyBinding SCAN_NOW;
    public static ChunkScanner SCANNER;

    @Override
    public void onInitializeClient() {
        SCANNER = new ChunkScanner();
        OPEN_GUI = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.seraphhack.open_gui", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_F12, "category.seraphhack"));
        SCAN_NOW = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.seraphhack.scan_now", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_F8, "category.seraphhack"));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            Handler.tick(client);
            while (OPEN_GUI.wasPressed()) {
                if (client.currentScreen == null) client.setScreen(new SeraphScreen());
            }
            while (SCAN_NOW.wasPressed()) {
                if (client.player != null && client.world != null) {
                    SCANNER.scanAround(client, client.player.getChunkPos().x, client.player.getChunkPos().z);
                }
            }
        });

        WorldRenderEvents.LAST.register(EspRenderer::render);
    }
}
