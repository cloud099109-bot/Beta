package com.seraph.seraphhack.scanner;

import com.seraph.seraphhack.Handler;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.chunk.WorldChunk;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public final class ChunkScanner {
    private final Map<Long, ChunkResult> results = new ConcurrentHashMap<>();
    private final BlockPos.Mutable pos = new BlockPos.Mutable();

    public void scanAround(MinecraftClient client, int cx, int cz) {
        if (client.world == null || !Handler.scanner) return;
        int r = Math.max(1, Handler.scanRadius);
        for (int dx = -r; dx <= r; dx++) for (int dz = -r; dz <= r; dz++) {
            WorldChunk chunk = client.world.getChunkManager().getWorldChunk(cx + dx, cz + dz, false);
            if (chunk != null) results.put(key(cx + dx, cz + dz), scanChunk(client.world, chunk));
        }
    }

    private ChunkResult scanChunk(ClientWorld world, WorldChunk chunk) {
        ChunkResult out = new ChunkResult(chunk.getPos().x, chunk.getPos().z);
        int minY = Math.max(world.getBottomY(), Handler.minY);
        int maxY = Math.min(world.getTopY() - 1, Handler.maxY);
        if (!Handler.underground) minY = Math.max(minY, world.getBottomY());

        for (int x = 0; x < 16; x++) for (int z = 0; z < 16; z++) {
            int flat = 0, air = 0;
            for (int y = minY; y <= maxY; y++) {
                pos.set(chunk.getPos().x * 16 + x, y, chunk.getPos().z * 16 + z);
                BlockState state = world.getBlockState(pos);
                if (state.isAir()) {
                    air++;
                    if (Handler.tunnelDetection && tunnelLike(world, pos)) out.tunnelBlocks++;
                    continue;
                }
                if (isInteresting(state)) out.artificialBlocks++;
                if (Handler.flatDetection && flatLike(world, pos)) flat++;
            }
            if (flat >= 7) out.flatBlocks += flat;
            if (Handler.airPocketDetection && air >= 10) out.airBlocks += air;
        }
        out.calculate();
        return out;
    }

    private boolean flatLike(ClientWorld w, BlockPos p) {
        if (!w.getBlockState(p).isSolidBlock(w, p) || !w.getBlockState(p.up()).isAir()) return false;
        return solid(w, p.north()) && solid(w, p.south()) && solid(w, p.east()) && solid(w, p.west());
    }

    private boolean solid(ClientWorld w, BlockPos p) { return w.getBlockState(p).isSolidBlock(w, p); }

    private boolean tunnelLike(ClientWorld w, BlockPos p) {
        int n = 0;
        if (w.getBlockState(p.north()).isAir()) n++;
        if (w.getBlockState(p.south()).isAir()) n++;
        if (w.getBlockState(p.east()).isAir()) n++;
        if (w.getBlockState(p.west()).isAir()) n++;
        return n >= 2;
    }

    private boolean isInteresting(BlockState s) {
        return s.isOf(Blocks.CHEST) || s.isOf(Blocks.TRAPPED_CHEST) || s.isOf(Blocks.BARREL) ||
                s.isOf(Blocks.OBSIDIAN) || s.isOf(Blocks.CRYING_OBSIDIAN) || s.isOf(Blocks.STONE_BRICKS) ||
                s.isOf(Blocks.DEEPSLATE_BRICKS) || s.isOf(Blocks.IRON_BLOCK) || s.isOf(Blocks.GOLD_BLOCK) ||
                s.isOf(Blocks.DIAMOND_BLOCK) || s.isOf(Blocks.EMERALD_BLOCK);
    }

    public Collection<ChunkResult> getResults() { return new ArrayList<>(results.values()); }
    public void clear() { results.clear(); }
    private static long key(int x, int z) { return ((long)x << 32) ^ (z & 0xffffffffL); }
}
