# Seraph Hack 1.2.0

Fabric 1.21.1 client-side utility/ESP/scanner project.

## Modules
- F12 GUI
- F8 manual chunk scan
- Vanilla-authorized flight helper (requires allowFlying)
- Elytra helper
- Auto Totem
- Player ESP
- Chest / trapped chest / barrel ESP
- Shulker ESP with per-color rendering
- Loaded-chunk anomaly scanner
- Underground, flat, tunnel and air-pocket analysis
- Suspicious chunk boxes

## Limits
ESP/scanning only uses entity/block/chunk data already available to the client. It does not bypass server anti-ESP, visibility restrictions, or anti-cheat.

## Build
Use JDK 21 and Fabric Loom. `./gradlew clean build` (or `gradlew.bat clean build` on Windows).

For phone-only users, the included GitHub Actions workflow can build the project remotely after uploading/pushing it to a GitHub repository.
